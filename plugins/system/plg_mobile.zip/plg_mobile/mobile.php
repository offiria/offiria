<?php

// no direct access
defined('_JEXEC') or die;

jimport('joomla.xfactory');
jimport('joomla.environment.browser');

/**
 * System Mobile Plugin
 */
if(!class_exists('plgSystemMobile'))
{
     class plgSystemMobile extends JPlugin
     {
	  function plgSystemMobile(& $subject, $config)
	  {
	       parent::__construct($subject, $config);

		 // detect the browser by checking user agent
		 $browser = JBrowser::getInstance();
		 if ($browser->isMobile()) {
		 }
	  }
     }
}